# mockamap
a simple map generator based on ROS

demo cases:

* perlin3d map

![Alt text](https://github.com/HKUST-Aerial-Robotics/mockamap/blob/master/images/perlin3d.png)

* post2d map

![Alt text](https://github.com/HKUST-Aerial-Robotics/mockamap/blob/master/images/post2d.png)

@misc{mockamap,
  author = "William.Wu",
  title = "mockamap",
  howpublished = "\url{https://github.com/HKUST-Aerial-Robotics/mockamap }",
}
